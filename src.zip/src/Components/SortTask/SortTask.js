import React from 'react'
import { Select } from '../StyleComponents/Button.style'
function SortTask() {
  return (
    <div>
         <Select>
          <option>High to low</option>
          <option>Low to high</option>
        </Select>
    </div>
  )
}



export default SortTask