import React from "react";

import KanbanBoard from "./Components/KanbanBoard";

function App() {
  return (
    <div>
      <KanbanBoard />
    </div>
  );
}

export default App;
